#ifndef _IMG_DEF_
#define _IMG_DEF_

/**
define image resources use index 256 format
**/

#endif