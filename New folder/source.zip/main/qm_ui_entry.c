/***
* author:xnby
* platform: esp
* version: 1.0.0
* UIResolution: 480*320
*/

#include "qm_ui_entry.h"
#include "cJSON.h"
#include <stdio.h>
#include <stdlib.h>
#include "lv_8ms_blockly.h"
#include "wtctrl.h"

typedef struct
{
    char *name;
    lv_obj_t **id;
} lv_widget_t;

typedef struct
{
    char *name;
    lv_obj_t **id;
    lv_widget_t *wids;
    int len;
} lv_screen_t;

void lvgl_blockly_loop();
void lvgl_blockly_init();
    /*
    * includes
    */
LV_IMG_DECLARE(img1627285685903_png);
LV_IMG_DECLARE(img1627285659756_png);
LV_IMG_DECLARE(img1627285614032_png);
LV_IMG_DECLARE(img1627285517798_png);
LV_IMG_DECLARE(img1627285477548_png);
LV_IMG_DECLARE(img1627285431674_png);
LV_IMG_DECLARE(img1627284951998_png);
LV_IMG_DECLARE(img1624810488518_JPG);
LV_IMG_DECLARE(img1624810449186_jpg);
LV_IMG_DECLARE(img1624810438726_jpg);
LV_IMG_DECLARE(img1624810316180_JPG);
LV_IMG_DECLARE(img1624810282247_JPG);
LV_IMG_DECLARE(img1623066079363_jpg);
LV_IMG_DECLARE(img1623066088293_jpg);
LV_IMG_DECLARE(img1623066069081_jpg);
LV_IMG_DECLARE(img1622133209398_png);
LV_IMG_DECLARE(img1622133193178_png);
LV_IMG_DECLARE(img1621964575797_png);
LV_IMG_DECLARE(img1621964562882_jpeg);
LV_IMG_DECLARE(img1621964554083_jpeg);
LV_IMG_DECLARE(img1621808007284_jpg);
LV_IMG_DECLARE(img1621807987411_jpg);
LV_IMG_DECLARE(img1621807977916_jpg);
LV_IMG_DECLARE(img1621807899832_jpg);
LV_IMG_DECLARE(img1621411672830_png);
LV_IMG_DECLARE(img1621412246918_png);
LV_IMG_DECLARE(img1621411957578_png);
LV_IMG_DECLARE(img1621411781237_png);
LV_IMG_DECLARE(img1621411653680_png);
LV_IMG_DECLARE(img1621411366311_png);
LV_IMG_DECLARE(img1621411186442_png);
LV_IMG_DECLARE(img1621411142878_png);
LV_IMG_DECLARE(img1621411133904_png);
LV_IMG_DECLARE(img1620925138709_png);
LV_IMG_DECLARE(img1620925120786_png);
LV_IMG_DECLARE(img1618503703351_jpg);
LV_IMG_DECLARE(img1615470201266_dxf);
LV_IMG_DECLARE(img1615470208855_jpeg);
LV_IMG_DECLARE(img1615470165637_JPG);
LV_IMG_DECLARE(img1615470154936_JPG);
LV_IMG_DECLARE(img1614344958239_jpeg);
LV_IMG_DECLARE(img1614160720599_png);
LV_IMG_DECLARE(imgbeijing_png);
LV_IMG_DECLARE(img1612941109111_jpg);
LV_IMG_DECLARE(img1612941076475_jpg);
LV_IMG_DECLARE(img1612941006287_jpg);
LV_IMG_DECLARE(img1607507036809_png);
LV_IMG_DECLARE(img1606101128378_png);
LV_IMG_DECLARE(img1606100693921_jpg);
LV_IMG_DECLARE(img1606099918107_jpg);
LV_IMG_DECLARE(img1606099887609_jpg);
LV_IMG_DECLARE(img1606099859915_jpg);
LV_IMG_DECLARE(img1603868419064_jpg);
LV_IMG_DECLARE(img1592530624099_png);
LV_IMG_DECLARE(img1592530553072_png);
    /*
    * declear main_screen
    */
lv_obj_t * main_screen;
lv_obj_t * image_9f2b;
lv_obj_t * label_ce35;
lv_obj_t * home;
lv_obj_t * image_1c09;
lv_obj_t * image_914f;
lv_obj_t * pH_diss;
    /*
    * declear setup
    */
lv_obj_t * setup;
lv_obj_t * image_57b1;
lv_obj_t * image_4654;
lv_obj_t * image_76ca;
lv_obj_t * image_7cdb;
lv_obj_t * dropdown_123c;
lv_obj_t * textarea_c8b8;
lv_obj_t * label_3e21;

lv_widget_t g_main_screen_ids[]=
{
    {"image_9f2b",&image_9f2b},

    {"label_ce35",&label_ce35},

    {"home",&home},

    {"image_1c09",&image_1c09},

    {"image_914f",&image_914f},

    {"pH_diss",&pH_diss},
};
lv_widget_t g_setup_ids[]=
{
    {"image_57b1",&image_57b1},

    {"image_4654",&image_4654},

    {"image_76ca",&image_76ca},

    {"image_7cdb",&image_7cdb},

    {"dropdown_123c",&dropdown_123c},

    {"textarea_c8b8",&textarea_c8b8},

    {"label_3e21",&label_3e21},
};

lv_screen_t g_screens[] =
{
    {"main_screen", &main_screen, g_main_screen_ids, (sizeof(g_main_screen_ids) / sizeof(g_main_screen_ids[0]))},
    {"setup", &setup, g_setup_ids, (sizeof(g_setup_ids) / sizeof(g_setup_ids[0]))},
};

LV_FONT_DECLARE(ali_font_16);
LV_FONT_DECLARE(ali_font_102);
LV_FONT_DECLARE(ali_font_38);


    void show_screen_main_screen();
    void show_screen_setup();
    /*
    * keyboard
    */
    lv_obj_t * g_kb = NULL;

    static void g_kb_event_cb(lv_obj_t * event_kb, lv_event_t event)
    {
    /* Just call the regular event handler */
    if(event == LV_EVENT_APPLY) {
    lv_obj_set_hidden(event_kb, true);
    } else if(event == LV_EVENT_CANCEL) {
    lv_obj_set_hidden(event_kb, true);
    } else {
    lv_keyboard_def_event_cb(event_kb, event);
    }
    }
    static void g_create_kb_ifneeded() {
    if(g_kb == NULL) {
    g_kb = lv_keyboard_create(lv_scr_act(), NULL);
    lv_obj_set_pos(g_kb, 5, 90);
    lv_obj_set_event_cb(g_kb, g_kb_event_cb); /* Setting a custom event handler stops the keyboard from closing automatically */
    lv_obj_set_size(g_kb,  LV_HOR_RES - 10, 140);
    lv_keyboard_set_cursor_manage(g_kb, true); /* Automatically show/hide cursors on text areas */
    lv_obj_set_hidden(g_kb, true);
    }
    }
static void g_show_kb() 
{
    g_create_kb_ifneeded();
    lv_obj_set_parent(g_kb, lv_scr_act());
    lv_obj_set_hidden(g_kb, false);
    lv_obj_align(g_kb,NULL,LV_ALIGN_IN_BOTTOM_MID,0,0);
}

    /**
    *开机启动屏相关
    */
    static lv_style_t style_star, style_black, style_url;
    LV_IMG_DECLARE(img_8ms_png);
    LV_IMG_DECLARE(img_star);
    lv_obj_t * logo;
    lv_obj_t * logo_star;
    lv_obj_t * url_label;
    lv_obj_t * url_mask;
    lv_obj_t * mask_layer;
    int timer_cnt = 0;
    /****
    * 临时变量用于数据传输
    */
    char _tmpbuf[32];

  

    
    /*
    * declear codes
    */



#ifndef LV_8MS_PRESET_UART_QUEUE
void lv_8ms_uart_queue_ana(uint8_t* data,int size){   
    printf("ana:%s\n",wtctrl_json_parse((char *)data));
}
#endif

/*
 * callback functions begins
 */
/*
 * callback functions ends
 */
    /*
    * init codes
    */
void init_function()
{
#ifdef BLOCKLY_init
    blockly_init();
#endif
    }

    void lv_8ms_image_9f2b_create()
{
    image_9f2b = lv_img_create(main_screen, NULL);
    lv_img_set_src(image_9f2b, &img1627284951998_png);
    lv_obj_set_pos(image_9f2b, 0, 0);
#ifdef BLOCKLY_image_9f2b_EVENT_HANDLER
    lv_obj_set_event_cb(image_9f2b, image_9f2b_event_handler);
#endif
}
    void lv_8ms_label_ce35_create()
{
	label_ce35 = lv_label_create(main_screen, NULL);
	lv_label_set_long_mode(label_ce35,LV_LABEL_LONG_BREAK);
	lv_obj_set_size(label_ce35, 266, 87);
//set label style
	lv_obj_set_style_local_text_color(label_ce35,LV_LABEL_PART_MAIN,LV_STATE_DEFAULT,LV_COLOR_MAKE(0xf5, 0x6c, 0x23));
	lv_obj_set_style_local_text_font(label_ce35,LV_LABEL_PART_MAIN,LV_STATE_DEFAULT,&ali_font_102);

	lv_label_set_text(label_ce35, "10.69");
	lv_label_set_align(label_ce35, LV_LABEL_ALIGN_CENTER);
#ifdef BLOCKLY_label_ce35_EVENT_HANDLER
	lv_obj_set_event_cb(label_ce35, label_ce35_event_handler);
#endif
	if(label_ce35->coords.x2-label_ce35->coords.x1<266)
	{
		int x_offset=(266-(label_ce35->coords.x2-label_ce35->coords.x1))/2;
		lv_obj_set_style_local_pad_left(label_ce35,LV_LABEL_PART_MAIN,LV_STATE_DEFAULT,x_offset);
		lv_obj_set_style_local_pad_right(label_ce35,LV_LABEL_PART_MAIN,LV_STATE_DEFAULT,x_offset);
	}
	if(label_ce35->coords.y2-label_ce35->coords.y1<87)
	{
		int y_offset=(87-(label_ce35->coords.y2-label_ce35->coords.y1))/2;
		lv_obj_set_style_local_pad_bottom(label_ce35,LV_LABEL_PART_MAIN,LV_STATE_DEFAULT,y_offset);
		lv_obj_set_style_local_pad_top(label_ce35,LV_LABEL_PART_MAIN,LV_STATE_DEFAULT,y_offset);
	}
		lv_obj_set_pos(label_ce35, 116, 96);

}
    void lv_8ms_home_create()
{
    home = lv_img_create(main_screen, NULL);
    lv_img_set_src(home, &img1627285431674_png);
    lv_obj_set_pos(home, 219, 246);
    lv_obj_set_click(home,true);
    lv_obj_set_style_local_image_recolor(home,LV_IMG_PART_MAIN,LV_STATE_PRESSED,LV_COLOR_BLACK);
    lv_obj_set_style_local_image_recolor_opa(home,LV_IMG_PART_MAIN,LV_STATE_PRESSED,60);
#ifdef BLOCKLY_home_EVENT_HANDLER
    lv_obj_set_event_cb(home, home_event_handler);
#endif
}
    void lv_8ms_image_1c09_create()
{
    image_1c09 = lv_img_create(main_screen, NULL);
    lv_img_set_src(image_1c09, &img1627285477548_png);
    lv_obj_set_pos(image_1c09, 305, 246);
    lv_obj_set_click(image_1c09,true);
    lv_obj_set_style_local_image_recolor(image_1c09,LV_IMG_PART_MAIN,LV_STATE_PRESSED,LV_COLOR_BLACK);
    lv_obj_set_style_local_image_recolor_opa(image_1c09,LV_IMG_PART_MAIN,LV_STATE_PRESSED,60);
#ifdef BLOCKLY_image_1c09_EVENT_HANDLER
    lv_obj_set_event_cb(image_1c09, image_1c09_event_handler);
#endif
}
    void lv_8ms_image_914f_create()
{
    image_914f = lv_img_create(main_screen, NULL);
    lv_img_set_src(image_914f, &img1627285517798_png);
    lv_obj_set_pos(image_914f, 133, 246);
    lv_obj_set_click(image_914f,true);
    lv_obj_set_style_local_image_recolor(image_914f,LV_IMG_PART_MAIN,LV_STATE_PRESSED,LV_COLOR_BLACK);
    lv_obj_set_style_local_image_recolor_opa(image_914f,LV_IMG_PART_MAIN,LV_STATE_PRESSED,60);
#ifdef BLOCKLY_image_914f_EVENT_HANDLER
    lv_obj_set_event_cb(image_914f, image_914f_event_handler);
#endif
}
    void lv_8ms_pH_diss_create()
{
	pH_diss = lv_label_create(main_screen, NULL);
	lv_label_set_long_mode(pH_diss,LV_LABEL_LONG_BREAK);
	lv_obj_set_size(pH_diss, 65, 46);
//set label style
	lv_obj_set_style_local_text_color(pH_diss,LV_LABEL_PART_MAIN,LV_STATE_DEFAULT,LV_COLOR_MAKE(0xf5, 0x6c, 0x23));
	lv_obj_set_style_local_text_font(pH_diss,LV_LABEL_PART_MAIN,LV_STATE_DEFAULT,&ali_font_38);

	lv_label_set_text(pH_diss, "pH");
	lv_label_set_align(pH_diss, LV_LABEL_ALIGN_CENTER);
#ifdef BLOCKLY_pH_diss_EVENT_HANDLER
	lv_obj_set_event_cb(pH_diss, pH_diss_event_handler);
#endif
	if(pH_diss->coords.x2-pH_diss->coords.x1<65)
	{
		int x_offset=(65-(pH_diss->coords.x2-pH_diss->coords.x1))/2;
		lv_obj_set_style_local_pad_left(pH_diss,LV_LABEL_PART_MAIN,LV_STATE_DEFAULT,x_offset);
		lv_obj_set_style_local_pad_right(pH_diss,LV_LABEL_PART_MAIN,LV_STATE_DEFAULT,x_offset);
	}
	if(pH_diss->coords.y2-pH_diss->coords.y1<46)
	{
		int y_offset=(46-(pH_diss->coords.y2-pH_diss->coords.y1))/2;
		lv_obj_set_style_local_pad_bottom(pH_diss,LV_LABEL_PART_MAIN,LV_STATE_DEFAULT,y_offset);
		lv_obj_set_style_local_pad_top(pH_diss,LV_LABEL_PART_MAIN,LV_STATE_DEFAULT,y_offset);
	}
		lv_obj_set_pos(pH_diss, 369, 73);

}
    void lv_8ms_image_57b1_create()
{
    image_57b1 = lv_img_create(setup, NULL);
    lv_img_set_src(image_57b1, &img1627285614032_png);
    lv_obj_set_pos(image_57b1, 0, 0);
#ifdef BLOCKLY_image_57b1_EVENT_HANDLER
    lv_obj_set_event_cb(image_57b1, image_57b1_event_handler);
#endif
}
    void lv_8ms_image_4654_create()
{
    image_4654 = lv_img_create(setup, NULL);
    lv_img_set_src(image_4654, &img1627285431674_png);
    lv_obj_set_pos(image_4654, 211, 243);
    lv_obj_set_click(image_4654,true);
    lv_obj_set_style_local_image_recolor(image_4654,LV_IMG_PART_MAIN,LV_STATE_PRESSED,LV_COLOR_BLACK);
    lv_obj_set_style_local_image_recolor_opa(image_4654,LV_IMG_PART_MAIN,LV_STATE_PRESSED,60);
#ifdef BLOCKLY_image_4654_EVENT_HANDLER
    lv_obj_set_event_cb(image_4654, image_4654_event_handler);
#endif
}
    void lv_8ms_image_76ca_create()
{
    image_76ca = lv_img_create(setup, NULL);
    lv_img_set_src(image_76ca, &img1627285659756_png);
    lv_obj_set_pos(image_76ca, 119, 243);
    lv_obj_set_click(image_76ca,true);
    lv_obj_set_style_local_image_recolor(image_76ca,LV_IMG_PART_MAIN,LV_STATE_PRESSED,LV_COLOR_BLACK);
    lv_obj_set_style_local_image_recolor_opa(image_76ca,LV_IMG_PART_MAIN,LV_STATE_PRESSED,60);
#ifdef BLOCKLY_image_76ca_EVENT_HANDLER
    lv_obj_set_event_cb(image_76ca, image_76ca_event_handler);
#endif
}
    void lv_8ms_image_7cdb_create()
{
    image_7cdb = lv_img_create(setup, NULL);
    lv_img_set_src(image_7cdb, &img1627285685903_png);
    lv_obj_set_pos(image_7cdb, 303, 243);
    lv_obj_set_click(image_7cdb,true);
    lv_obj_set_style_local_image_recolor(image_7cdb,LV_IMG_PART_MAIN,LV_STATE_PRESSED,LV_COLOR_BLACK);
    lv_obj_set_style_local_image_recolor_opa(image_7cdb,LV_IMG_PART_MAIN,LV_STATE_PRESSED,60);
#ifdef BLOCKLY_image_7cdb_EVENT_HANDLER
    lv_obj_set_event_cb(image_7cdb, image_7cdb_event_handler);
#endif
}
    void lv_8ms_dropdown_123c_create()
{
    dropdown_123c = lv_dropdown_create(setup, NULL);
    lv_obj_set_size(dropdown_123c, 123, 40);
    lv_obj_set_pos(dropdown_123c, 8, 11);
    lv_dropdown_set_options(dropdown_123c,
    "Fitler 1""\n"
    "Filter 2""\n"
    "Filter 3""\n"
    "Filter 4""\n"
    "Filter 5""\n"
    "Filter 6""\n"
    "Filter 7""\n"
    "Filter 8""\n"
    ""
);
    lv_dropdown_set_draw_arrow(dropdown_123c, true);
#ifdef BLOCKLY_dropdown_123c_EVENT_HANDLER
    lv_obj_set_event_cb(dropdown_123c, dropdown_123c_event_handler);
#endif
/*
设置字体大小颜色
*/
    lv_obj_set_style_local_text_color(dropdown_123c,LV_DROPDOWN_PART_MAIN,LV_STATE_DEFAULT,LV_COLOR_MAKE(0x15, 0x7a, 0xe9));
    lv_obj_set_style_local_text_color(dropdown_123c,LV_DROPDOWN_PART_LIST,LV_STATE_DEFAULT,LV_COLOR_MAKE(0x15, 0x7a, 0xe9));
/*
设置字体大小颜色结束
*/
}
    void lv_8ms_label_3e21_create()
{
	label_3e21 = lv_label_create(setup, NULL);
	lv_label_set_long_mode(label_3e21,LV_LABEL_LONG_BREAK);
	lv_obj_set_size(label_3e21, 184, 40);
//set label style
	lv_obj_set_style_local_text_font(label_3e21,LV_LABEL_PART_MAIN,LV_STATE_DEFAULT,&ali_font_16);

	lv_label_set_text(label_3e21, "labelqfwfqqwwqfwqf");
	lv_label_set_align(label_3e21, LV_LABEL_ALIGN_CENTER);
#ifdef BLOCKLY_label_3e21_EVENT_HANDLER
	lv_obj_set_event_cb(label_3e21, label_3e21_event_handler);
#endif
	if(label_3e21->coords.x2-label_3e21->coords.x1<184)
	{
		int x_offset=(184-(label_3e21->coords.x2-label_3e21->coords.x1))/2;
		lv_obj_set_style_local_pad_left(label_3e21,LV_LABEL_PART_MAIN,LV_STATE_DEFAULT,x_offset);
		lv_obj_set_style_local_pad_right(label_3e21,LV_LABEL_PART_MAIN,LV_STATE_DEFAULT,x_offset);
	}
	if(label_3e21->coords.y2-label_3e21->coords.y1<40)
	{
		int y_offset=(40-(label_3e21->coords.y2-label_3e21->coords.y1))/2;
		lv_obj_set_style_local_pad_bottom(label_3e21,LV_LABEL_PART_MAIN,LV_STATE_DEFAULT,y_offset);
		lv_obj_set_style_local_pad_top(label_3e21,LV_LABEL_PART_MAIN,LV_STATE_DEFAULT,y_offset);
	}
		lv_obj_set_pos(label_3e21, 162, 24);

}

void show_screen_main_screen()
{
        lv_scr_load(main_screen);
//生成动态页面的style
    
}
void show_screen_setup()
{
        lv_scr_load(setup);
//生成动态页面的style
    
}

int screen_loop_enter = 0;
int _delay = 0;
void lv_qm_ui_loop(void)
{
        /**
* image_9f2b动画切换
*/
if(image_9f2b_anmi_on) {
    if((image_9f2b_anmi_index % 20) == 0) {
    lv_img_set_src(image_9f2b, image_9f2b_anmi[image_9f2b_anmi_index/20]);
    if(image_9f2b_anmi_index == 0*20) {
    image_9f2b_anmi_index = -19;
    }
    }
    image_9f2b_anmi_index ++;
}
        
        
        
        
        
        
        
    #ifdef BLOCKLY_loop
    blockly_loop();
    #endif
}

void lv_qm_ui_entry(void)
{
    
    /*
    * create screens
    */
    main_screen = lv_obj_create(NULL, NULL);
    setup = lv_obj_create(NULL, NULL);
    
    lv_scr_load(main_screen);

//CREATE STATIC OBJ
    lv_8ms_image_9f2b_create();
    lv_8ms_label_ce35_create();
    lv_8ms_home_create();
    lv_8ms_image_1c09_create();
    lv_8ms_image_914f_create();
    lv_8ms_pH_diss_create();
    lv_8ms_image_57b1_create();
    lv_8ms_image_4654_create();
    lv_8ms_image_76ca_create();
    lv_8ms_image_7cdb_create();
    lv_8ms_dropdown_123c_create();
    lv_8ms_textarea_c8b8_create();
    lv_8ms_label_3e21_create();
  
    init_function();
}
/**
* @brief blockly initialization
*/

void lvgl_blockly_init()
{
#ifdef WT_WIFI
    blockly_wifi_init();
#endif // DEBUG
#ifdef WT_BLUFI
    blockly_blufi_init();
#endif // DEBUG
#ifdef WT_HTTP_REQUEST
    blockly_http_init();
#endif // WT_HTTP_REQUEST
}

/**
* @brief blockly loop
*/

void lvgl_blockly_loop()
{
#ifdef WT_BLUFI
    blockly_blufi_loop();
#endif // DEBUG
#ifdef WT_WIFI
    blockly_wifi_loop();
#endif // DEBUG
#ifdef WT_HTTP_REQUEST
    blockly_http_loop();
#endif // WT_HTTP_REQUEST
}

void lvgl_device_init(void)
{
#ifdef ESP32_GPIO
    lv_8ms_gpio_setup();
#endif
#ifdef ESP32_TIMER
    lv_8ms_timer_setup();
#endif
#ifdef ESP32_UART
    lv_8ms_uart_setup();
#endif
}

void lvgl_device_loop(void)
{
#ifdef ESP32_GPIO
    lv_8ms_gpio_loop();
#endif
#ifdef ESP32_TIMER
    lv_8ms_timer_loop();
#endif
#ifdef ESP32_UART
    lv_8ms_uart_loop();
#endif
}
lv_obj_t *lv_8ms_get_screen(char *name)
{
    int i = 0;
    for (i = 0; i < (sizeof(g_screens) / sizeof(g_screens[0])); i++)
    {
        if (!strcmp(name, g_screens[i].name))
        {
            return *(g_screens[i].id);
        }
    }
    return NULL;
}

lv_obj_t *lv_8ms_get_widget(char *w_name)
{
    int i = 0, j = 0;

    for (i = 0; i < (sizeof(g_screens) / sizeof(g_screens[0])); i++)
    {
        for (j = 0; j <  g_screens[i].len; j++)
        {
            if (!strcmp(w_name, g_screens[i].wids[j].name))
            {
                return *(g_screens[i].wids[j].id);
            }
        }
    }

    return NULL;
}

const char *lv_8ms_get_obj_name(lv_obj_t *obj)
{
    if (!obj) {
        return NULL;
    }

    int i = 0, j = 0;
    for (i = 0; i < (sizeof(g_screens) / sizeof(g_screens[0])); i++)
    {
        if (*(g_screens[i].id) == obj) {
            return g_screens[i].name;
        }

        for (j = 0; j <  g_screens[i].len; j++)
        {
            if (*(g_screens[i].wids[j].id) == obj)
            {
                return g_screens[i].wids[j].name;
            }
        }
    }

    return NULL;
}